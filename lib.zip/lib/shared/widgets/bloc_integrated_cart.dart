import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:izam_task/features/cart/bloc/cart_bloc.dart';
import 'package:izam_task/features/cart/bloc/cart_event.dart';
import 'package:izam_task/features/cart/bloc/cart_state.dart';
import 'package:izam_task/features/cart/entities/cart.dart';
import 'package:izam_task/shared/widgets/shopping_cart_widget.dart';

/// A widget that integrates ShoppingCartWidget with CartBloc
class BlocIntegratedCart extends StatelessWidget {
  final bool showCheckoutButton;
  final bool showClearButton;
  final String? emptyCartMessage;
  final String? checkoutButtonText;
  final VoidCallback? onCheckout;

  const BlocIntegratedCart({
    super.key,
    this.showCheckoutButton = true,
    this.showClearButton = true,
    this.emptyCartMessage,
    this.checkoutButtonText,
    this.onCheckout,
  });

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CartBloc, CartState>(
      builder: (context, state) {
        if (state is CartLoaded) {
          return ShoppingCartWidget(
            cart: state.cart,
            onUpdateQuantity: (itemId, newQuantity) {
              context.read<CartBloc>().add(UpdateQuantity(itemId, newQuantity));
            },
            onRemoveItem: (itemId) {
              context.read<CartBloc>().add(RemoveFromCart(itemId));
            },
            onClearCart: () {
              context.read<CartBloc>().add(ClearCart());
            },
            onCheckout: onCheckout ?? _defaultCheckout(context, state.cart),
            showCheckoutButton: showCheckoutButton,
            showClearButton: showClearButton,
            emptyCartMessage: emptyCartMessage,
            checkoutButtonText: checkoutButtonText,
          );
        }

        if (state is CartError) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.error, size: 64, color: Colors.red),
                const SizedBox(height: 16),
                Text('Error: ${state.message}', style: const TextStyle(fontSize: 16), textAlign: TextAlign.center),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () {
                    // You might want to add a retry event to your CartBloc
                    // For now, we'll just show a message
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please try again')));
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF6366F1), foregroundColor: Colors.white),
                  child: const Text('Retry'),
                ),
              ],
            ),
          );
        }

        // Loading state
        return const Center(child: CircularProgressIndicator());
      },
    );
  }

  VoidCallback _defaultCheckout(BuildContext context, Cart cart) {
    return () {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Checkout: ${cart.items.length} items, Total: \$${cart.totals.total > 0 ? cart.totals.total.toStringAsFixed(2) : cart.totals.subtotal.toStringAsFixed(2)}',
          ),
          backgroundColor: const Color(0xFF6366F1),
        ),
      );
    };
  }
}

/// Example page using the integrated cart
class IntegratedCartPage extends StatelessWidget {
  const IntegratedCartPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Cart'), backgroundColor: const Color(0xFF6366F1), foregroundColor: Colors.white),
      body: const BlocIntegratedCart(emptyCartMessage: 'Your shopping cart is empty', checkoutButtonText: 'Proceed to Payment'),
    );
  }
}

/// Example of a mini cart widget for showing in drawers, bottom sheets, etc.
class MiniCartWidget extends StatelessWidget {
  const MiniCartWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CartBloc, CartState>(
      builder: (context, state) {
        if (state is CartLoaded) {
          if (state.cart.items.isEmpty) {
            return const Padding(
              padding: EdgeInsets.all(16.0),
              child: Text('Your cart is empty', style: TextStyle(fontSize: 16, color: Colors.grey), textAlign: TextAlign.center),
            );
          }

          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Mini cart header
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF6366F1).withOpacity(0.1),
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Cart (${state.cart.items.length} items)', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    Text(
                      '\$${state.cart.totals.total > 0 ? state.cart.totals.total.toStringAsFixed(2) : state.cart.totals.subtotal.toStringAsFixed(2)}',
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF6366F1)),
                    ),
                  ],
                ),
              ),
              // Constrained cart widget
              SizedBox(
                height: 300,
                child: ShoppingCartWidget(
                  cart: state.cart,
                  onUpdateQuantity: (itemId, newQuantity) {
                    context.read<CartBloc>().add(UpdateQuantity(itemId, newQuantity));
                  },
                  onRemoveItem: (itemId) {
                    context.read<CartBloc>().add(RemoveFromCart(itemId));
                  },
                  onClearCart: () {
                    context.read<CartBloc>().add(ClearCart());
                  },
                  onCheckout: () {
                    Navigator.pop(context); // Close mini cart
                    // Navigate to checkout
                    ScaffoldMessenger.of(
                      context,
                    ).showSnackBar(const SnackBar(content: Text('Navigating to checkout...'), backgroundColor: Color(0xFF6366F1)));
                  },
                  showClearButton: false,
                  checkoutButtonText: 'Checkout',
                ),
              ),
            ],
          );
        }

        return const SizedBox(height: 100, child: Center(child: CircularProgressIndicator()));
      },
    );
  }
}
