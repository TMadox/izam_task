abstract class CatalogEvent {}

class LoadCatalog extends CatalogEvent {}