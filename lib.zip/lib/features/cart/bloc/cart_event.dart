import 'package:izam_task/features/catalog/entities/item.dart';

abstract class CartEvent {}

class AddToCart extends CartEvent {
  final Item item;
  final int quantity;

  AddToCart(this.item, {this.quantity = 1});
}

class RemoveFromCart extends CartEvent {
  final String itemId;

  RemoveFromCart(this.itemId);
}

class UpdateQuantity extends CartEvent {
  final String itemId;
  final int quantity;

  UpdateQuantity(this.itemId, this.quantity);
}

class ApplyCartDiscount extends CartEvent {
  final double discountPercentage;
  ApplyCartDiscount(this.discountPercentage);
}

class RemoveCartDiscount extends CartEvent {}

class ClearCart extends CartEvent {
  final bool isUndo;
  ClearCart({this.isUndo = false});
}

class UndoLastAction extends CartEvent {}

class Checkout extends CartEvent {}
