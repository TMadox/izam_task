import 'package:hydrated_bloc/hydrated_bloc.dart';
import 'package:izam_task/features/cart/bloc/cart_event.dart';
import 'package:izam_task/features/cart/bloc/cart_state.dart';
import 'package:izam_task/features/cart/entities/cart.dart';
import 'package:izam_task/features/cart/entities/cart_item.dart';
import 'package:izam_task/features/cart/entities/cart_totals.dart';
import 'package:izam_task/features/cart/entities/receipt.dart';

class CartBloc extends HydratedBloc<CartEvent, CartState> {
  // VAT rate as specified: 15%
  static const double _vatRate = 0.15;

  CartState? _previousState;

  CartBloc() : super(CartLoaded(Cart(items: [], totals: CartTotals()))) {
    on<AddToCart>(_onAddToCart);
    on<ClearCart>(_onClearCart);
    on<RemoveFromCart>(_onRemoveFromCart);
    on<UpdateQuantity>(_onUpdateQuantity);
    on<UndoLastAction>(_onUndoLastAction);
    on<ApplyCartDiscount>(_onApplyCartDiscount);
    on<RemoveCartDiscount>(_onRemoveCartDiscount);
    on<Checkout>(_onCheckout);
  }

  @override
  void onTransition(Transition<CartEvent, CartState> transition) {
    // Only save undo state for mutating events
    if (transition.event is AddToCart ||
        transition.event is RemoveFromCart ||
        transition.event is UpdateQuantity ||
        transition.event is ApplyCartDiscount ||
        transition.event is RemoveCartDiscount ||
        transition.event is ClearCart) {
      _previousState = transition.currentState;
    }
    super.onTransition(transition);
  }

  Future<void> _onUndoLastAction(UndoLastAction event, Emitter<CartState> emit) async {
    if (_previousState != null && _previousState is CartLoaded) {
      emit((_previousState! as CartLoaded).copyWith(isUndo: true));
      _previousState = null;
    }
  }

  @override
  CartState? fromJson(Map<String, dynamic> json) {
    try {
      if (json['type'] == 'CartLoaded') {
        final cart = Cart.fromJson(json['cart'] as Map<String, dynamic>);
        return CartLoaded(cart);
      }
      return CartLoaded(Cart(items: [], totals: CartTotals()));
    } catch (e) {
      // If there's an error loading the state, return initial state
      return CartLoaded(Cart(items: [], totals: CartTotals()));
    }
  }

  @override
  Map<String, dynamic>? toJson(CartState state) {
    if (state is CartLoaded) {
      return {'type': 'CartLoaded', 'cart': state.cart.toJson()};
    }
    return {'type': 'CartInitial'};
  }

  void _onAddToCart(AddToCart event, Emitter<CartState> emit) {
    final currentState = state;
    if (currentState is! CartLoaded) return;

    final currentItems = List<CartItem>.from(currentState.cart.items);
    final existingItemIndex = currentItems.indexWhere((cartItem) => cartItem.item.id == event.item.id);

    if (existingItemIndex != -1) {
      currentItems[existingItemIndex] = currentItems[existingItemIndex].copyWith(quantity: currentItems[existingItemIndex].quantity + event.quantity);
    } else {
      currentItems.add(CartItem(item: event.item, quantity: event.quantity));
    }

    final totals = _calculateTotals(currentItems, currentState.cart.cartDiscountPercentage);
    emit(CartLoaded(Cart(items: currentItems, totals: totals, cartDiscountPercentage: currentState.cart.cartDiscountPercentage)));
  }

  void _onRemoveFromCart(RemoveFromCart event, Emitter<CartState> emit) {
    final currentState = state;
    if (currentState is! CartLoaded) return;

    final currentItems = List<CartItem>.from(currentState.cart.items);
    currentItems.removeWhere((cartItem) => cartItem.item.id == event.itemId);

    final totals = _calculateTotals(currentItems, currentState.cart.cartDiscountPercentage);
    emit(CartLoaded(Cart(items: currentItems, totals: totals, cartDiscountPercentage: currentState.cart.cartDiscountPercentage)));
  }

  void _onUpdateQuantity(UpdateQuantity event, Emitter<CartState> emit) {
    if (event.quantity <= 0) {
      _onRemoveFromCart(RemoveFromCart(event.itemId), emit);
      return;
    }

    final currentState = state;
    if (currentState is! CartLoaded) return;

    final currentItems = List<CartItem>.from(currentState.cart.items);
    final itemIndex = currentItems.indexWhere((cartItem) => cartItem.item.id == event.itemId);

    if (itemIndex != -1) {
      currentItems[itemIndex] = currentItems[itemIndex].copyWith(quantity: event.quantity);
      final totals = _calculateTotals(currentItems, currentState.cart.cartDiscountPercentage);
      emit(CartLoaded(Cart(items: currentItems, totals: totals, cartDiscountPercentage: currentState.cart.cartDiscountPercentage)));
    }
  }

  void _onClearCart(ClearCart event, Emitter<CartState> emit) => emit(CartLoaded(Cart(items: [], totals: CartTotals()), isUndo: event.isUndo));

  void _onApplyCartDiscount(ApplyCartDiscount event, Emitter<CartState> emit) {
    final currentState = state;
    if (currentState is! CartLoaded) return;

    final updatedCart = currentState.cart.copyWith(cartDiscountPercentage: event.discountPercentage);

    final totals = _calculateTotals(updatedCart.items, updatedCart.cartDiscountPercentage);
    emit(CartLoaded(updatedCart.copyWith(totals: totals)));
  }

  void _onRemoveCartDiscount(RemoveCartDiscount event, Emitter<CartState> emit) {
    final currentState = state;
    if (currentState is! CartLoaded) return;

    final updatedCart = currentState.cart.copyWith(cartDiscountPercentage: 0.0);

    final totals = _calculateTotals(updatedCart.items, updatedCart.cartDiscountPercentage);
    emit(CartLoaded(updatedCart.copyWith(totals: totals)));
  }

  void _onCheckout(Checkout event, Emitter<CartState> emit) {
    final currentState = state;
    if (currentState is! CartLoaded) return;

    try {
      // Use the pure function to build the receipt
      final receipt = buildReceipt((currentState).cart, DateTime.now());
      // Emit checkout success state with the receipt
      emit(CartCheckoutSuccess(receipt));
    } catch (e) {
      emit(CartError('Failed to process checkout: ${e.toString()}'));
    }
  }

  CartTotals _calculateTotals(List<CartItem> items, [double cartDiscountPercentage = 0.0]) {
    // subtotal = Σ lineNet (sum of all line net amounts)
    final subtotal = items.fold(0.0, (sum, item) => sum + item.lineNet);

    // cartDiscount = subtotal × cartDiscountPercentage
    final cartDiscount = subtotal * cartDiscountPercentage;

    // vat = (subtotal - cartDiscount) × 0.15
    final vat = (subtotal - cartDiscount) * _vatRate;

    // grandTotal = subtotal - cartDiscount + vat
    final grandTotal = subtotal - cartDiscount + vat;

    // Calculate total discount amount for display purposes (item discounts + cart discount)
    final totalWithoutDiscount = items.fold(0.0, (sum, item) => sum + (item.item.price * item.quantity));
    final itemDiscounts = totalWithoutDiscount - subtotal;
    final totalDiscount = itemDiscounts + cartDiscount;

    return CartTotals(subtotal: subtotal, vat: vat, grandTotal: grandTotal, discount: totalDiscount);
  }
}
