import 'package:izam_task/features/cart/entities/cart.dart';

/// Receipt DTO with header, lines, and totals structure
class Receipt {
  final ReceiptHeader header;
  final List<ReceiptLine> lines;
  final ReceiptTotals totals;

  const Receipt({required this.header, required this.lines, required this.totals});

  @override
  String toString() {
    final buffer = StringBuffer();

    buffer.writeln('=' * 40);
    buffer.writeln('RECEIPT #${header.receiptNumber}');
    buffer.writeln('=' * 40);
    buffer.writeln('Date: ${header.formattedTimestamp}');
    buffer.writeln('-' * 40);

    for (final line in lines) {
      buffer.writeln('${line.itemName} x${line.quantity}');
      buffer.writeln('  \$${line.unitPrice.toStringAsFixed(2)} each = \$${line.lineTotal.toStringAsFixed(2)}');
    }

    buffer.writeln('-' * 40);
    buffer.writeln('Subtotal: \$${totals.subtotal.toStringAsFixed(2)}');
    buffer.writeln('VAT (15%): \$${totals.vat.toStringAsFixed(2)}');
    buffer.writeln('=' * 40);
    buffer.writeln('TOTAL: \$${totals.grandTotal.toStringAsFixed(2)}');
    buffer.writeln('=' * 40);

    return buffer.toString();
  }
}

/// Receipt header information
class ReceiptHeader {
  final String receiptNumber;
  final DateTime timestamp;

  const ReceiptHeader({required this.receiptNumber, required this.timestamp});

  String get formattedTimestamp {
    return '${timestamp.year}-${timestamp.month.toString().padLeft(2, '0')}-${timestamp.day.toString().padLeft(2, '0')} '
        '${timestamp.hour.toString().padLeft(2, '0')}:${timestamp.minute.toString().padLeft(2, '0')}';
  }
}

/// Individual line item in the receipt
class ReceiptLine {
  final String itemId;
  final String itemName;
  final int quantity;
  final double unitPrice;
  final double lineTotal;

  const ReceiptLine({required this.itemId, required this.itemName, required this.quantity, required this.unitPrice, required this.lineTotal});
}

/// Receipt totals summary
class ReceiptTotals {
  final double vat;
  final double discount;
  final double subtotal;
  final double grandTotal;

  const ReceiptTotals({required this.subtotal, required this.vat, required this.grandTotal, required this.discount});
}

/// Pure function to build a receipt from cart state

Receipt buildReceipt(Cart cart, DateTime timestamp) {
  // Validate cart state

  // Generate receipt number
  final receiptNumber = 'R${timestamp.millisecondsSinceEpoch.toString().substring(0, 8).toUpperCase()}';

  // Build header
  final header = ReceiptHeader(receiptNumber: receiptNumber, timestamp: timestamp);

  // Build lines from cart items
  final lines =
      cart.items
          .map(
            (cartItem) => ReceiptLine(
              itemId: cartItem.item.id,
              itemName: cartItem.item.name,
              quantity: cartItem.quantity,
              unitPrice: cartItem.item.price,
              lineTotal: cartItem.lineNet,
            ),
          )
          .toList();

  // Build totals
  final totals = ReceiptTotals(
    subtotal: cart.totals.subtotal,
    vat: cart.totals.vat,
    grandTotal: cart.totals.grandTotal,
    discount: cart.totals.discount,
  );

  return Receipt(header: header, lines: lines, totals: totals);
}
