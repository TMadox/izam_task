import 'package:izam_task/features/catalog/entities/item.dart';

class CartItem {
  final Item item;
  final int quantity;
  final double discountPercentage; // Added discount percentage per line

  const CartItem({
    required this.item,
    required this.quantity,
    this.discountPercentage = 0.0, // Default to 0% discount
  });

  CartItem copyWith({Item? item, int? quantity, double? discountPercentage}) =>
      CartItem(item: item ?? this.item, quantity: quantity ?? this.quantity, discountPercentage: discountPercentage ?? this.discountPercentage);

  // lineNet = price × qty × (1 – discount%)
  double get lineNet => item.price * quantity * (1 - discountPercentage);

  // Keep totalPrice for backwards compatibility, but now it uses lineNet
  double get totalPrice => lineNet;

  factory CartItem.fromJson(Map<String, dynamic> json) {
    return CartItem(
      item: Item.fromJson(json['item'] as Map<String, dynamic>),
      quantity: json['quantity'] as int,
      discountPercentage: (json['discountPercentage'] as num).toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {'item': item.toJson(), 'quantity': quantity, 'discountPercentage': discountPercentage};
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CartItem &&
          runtimeType == other.runtimeType &&
          item == other.item &&
          quantity == other.quantity &&
          discountPercentage == other.discountPercentage;

  @override
  int get hashCode => item.hashCode ^ quantity.hashCode ^ discountPercentage.hashCode;

  @override
  String toString() {
    return 'CartItem(item: ${item.name}, quantity: $quantity, discountPercentage: ${(discountPercentage * 100).toStringAsFixed(1)}%, lineNet: \$${lineNet.toStringAsFixed(2)})';
  }
}
